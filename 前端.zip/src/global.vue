<script>
const BASE_ID=100;
const DETA_ID=0;
const RUNNING_TASK_LIST=[
    {'trainTaskId':'101','trainTaskName':'MINIST_90_1'},
];
  export default
  {
    BASE_ID,
    DETA_ID,
    RUNNING_TASK_LIST,
  }
</script>