<template>
  <aside>这里是一些注意事项的位置，以后可以进行补充。</aside>
</template>

<script>
export default {
  name: 'Warning'
}
</script>

<style scoped>

</style>
