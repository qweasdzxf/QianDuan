
<template>
  <algorithmlist />

</template>

<script>

import Warning from '@/views/algorithm/components/warning'
import algorithmlist from '@/views/algorithm/components/algorithmlist'

export default {
  name: 'List',
  components: { algorithmlist, Warning }
}

</script>
<style scoped>
  /*.demo-table-expand {*/
  /*  font-size: 0;*/
  /*}*/
  /*.demo-table-expand label {*/
  /*  width: 90px;*/
  /*  color: #99a9bf;*/
  /*}*/
  /*.demo-table-expand .el-form-item {*/
  /*  margin-right: 0;*/
  /*  margin-bottom: 0;*/
  /*  width: 50%;*/
  /*}*/
  /*.el-table{*/
  /*  align-content: center;*/
  /*}*/

</style>
