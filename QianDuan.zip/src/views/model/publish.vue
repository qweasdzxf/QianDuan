<template>

</template>

<script>
  export default {
    name: 'publish'
  }
</script>

<style scoped>

</style>
