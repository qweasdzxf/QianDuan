<template>

</template>

<script>
  export default {
    name: 'market'
  }
</script>

<style scoped>

</style>
