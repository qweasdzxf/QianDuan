<template>
  <Detail />
</template>

<script>
import Detail from '@/views/algorithm/components/detail'
export default {
  name: 'Create',
  components: {
    Detail
  }
}
</script>

<style scoped>

</style>
